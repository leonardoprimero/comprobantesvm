"""
Módulo watcher - Monitor de carpeta para procesar archivos nuevos.
"""

from watcher.folder_watcher import FolderWatcher

__all__ = ['FolderWatcher']
