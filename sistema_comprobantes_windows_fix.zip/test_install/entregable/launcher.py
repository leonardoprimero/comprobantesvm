#!/usr/bin/env python3
"""
Launcher con Interfaz Gráfica (GUI) Nativa para el Sistema de Comprobantes.
Usa tkinter estándar para máxima compatibilidad y estabilidad.
"""
import os
import sys
import json
import threading
import subprocess
import time
import signal
import logging
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from app.license import LicenseManager

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Config path
CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'config.json')

class SystemLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Comprobantes - Launcher")
        self.root.geometry("700x550")
        
        # Estilos
        self.style = ttk.Style()
        self.style.theme_use('clam') # Tema más moderno que el default

        # Variables de estado
        self.process_api = None
        self.process_bot = None
        self.is_running = False
        self.license_active = True
        self.license_msg = ""
        self.messages_queue = []
        
        # Cargar configuración y licencia
        self.load_config_and_license()

        # Notebook (Pestañas)
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(expand=True, fill='both', padx=10, pady=10)

        # Crear pestañas
        self.tab_dashboard = ttk.Frame(self.notebook)
        self.tab_config = ttk.Frame(self.notebook)
        self.tab_logs = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_dashboard, text='Dashboard')
        self.notebook.add(self.tab_config, text='Configuración')
        self.notebook.add(self.tab_logs, text='Logs')

        # --- SETUP TABS ---
        self.setup_dashboard()
        self.setup_config()
        self.setup_logs()
        
        # Loop de actualización de UI
        self.root.after(100, self.update_ui_loop)
        
        # Loop de stats
        self.monitor_thread = threading.Thread(target=self.stats_monitor, daemon=True)
        self.monitor_thread.start()
        
        # Manejar cierre
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

    def load_config_and_license(self):
        self.config = {}
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        except:
            self.config = {}

        try:
            client_id = self.config.get("client_id", "")
            license_url = self.config.get("license_url", "")
            if client_id:
                lm = LicenseManager(client_id, license_url)
                self.license_active, self.license_msg = lm.check_license()
            else:
                 self.license_active, self.license_msg = True, "Modo Developer"
        except:
            self.license_active, self.license_msg = True, "Offline (Error)"

    def setup_dashboard(self):
        # Frame Principal
        frame = ttk.Frame(self.tab_dashboard)
        frame.pack(expand=True, fill='both', padx=20, pady=20)

        # Estado Licencia / Sistema
        if not self.license_active:
            lbl = ttk.Label(frame, text=f"⛔ BLOQUEADO: {self.license_msg}", 
                          font=("Helvetica", 14, "bold"), foreground="red")
            lbl.pack(pady=20)
            return

        self.lbl_status = ttk.Label(frame, text="Estado: DETENIDO", 
                                  font=("Helvetica", 18, "bold"), foreground="red")
        self.lbl_status.pack(pady=20)

        # Botones
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(pady=10)

        self.btn_start = ttk.Button(btn_frame, text="▶ INICIAR SISTEMA", command=self.start_system)
        self.btn_start.pack(side='left', padx=10, ipadx=10, ipady=5)

        self.btn_stop = ttk.Button(btn_frame, text="⏹ DETENER", command=self.stop_system, state='disabled')
        self.btn_stop.pack(side='left', padx=10, ipadx=10, ipady=5)

        # Costos
        cost_frame = ttk.LabelFrame(frame, text=" Resumen de Costos ", padding=15)
        cost_frame.pack(fill='x', pady=20)

        self.lbl_processed = ttk.Label(cost_frame, text="Procesados: 0", font=("Helvetica", 12))
        self.lbl_processed.pack()

        self.lbl_cost = ttk.Label(cost_frame, text="Costo Total: $0.00 USD", 
                                font=("Helvetica", 16, "bold"), foreground="blue")
        self.lbl_cost.pack(pady=5)

        # Excel
        ttk.Button(frame, text="📂 Abrir Excel", command=self.open_excel).pack(pady=20)

    def setup_config(self):
        frame = ttk.Frame(self.tab_config)
        frame.pack(expand=True, fill='both', padx=20, pady=20)
        
        # Variables Bindeadas
        fuentes = self.config.get('fuentes', {})
        storage = self.config.get('storage', {})
        
        self.var_whatsapp = tk.BooleanVar(value=fuentes.get('whatsapp_enabled', True))
        self.var_folder = tk.BooleanVar(value=fuentes.get('carpeta_enabled', False))
        self.var_folder_path = tk.StringVar(value=fuentes.get('carpeta_ruta', ''))
        
        self.var_excel = tk.BooleanVar(value=storage.get('excel_enabled', True))
        self.var_excel_path = tk.StringVar(value=storage.get('excel_path', 'transferencias.xlsx'))
        
        self.var_sheets = tk.BooleanVar(value=storage.get('sheets_enabled', False))
        self.var_sheets_id = tk.StringVar(value=storage.get('sheets_id', ''))

        # UI Fuentes
        lf_fuentes = ttk.LabelFrame(frame, text=" Fuentes ", padding=10)
        lf_fuentes.pack(fill='x', pady=5)
        
        ttk.Checkbutton(lf_fuentes, text="WhatsApp", variable=self.var_whatsapp).pack(anchor='w')
        ttk.Checkbutton(lf_fuentes, text="Carpeta Local", variable=self.var_folder).pack(anchor='w')
        ttk.Entry(lf_fuentes, textvariable=self.var_folder_path).pack(fill='x', pady=2)

        # UI Storage
        lf_storage = ttk.LabelFrame(frame, text=" Almacenamiento ", padding=10)
        lf_storage.pack(fill='x', pady=10)
        
        ttk.Checkbutton(lf_storage, text="Excel Local", variable=self.var_excel).pack(anchor='w')
        ttk.Entry(lf_storage, textvariable=self.var_excel_path).pack(fill='x', pady=2)
        
        ttk.Checkbutton(lf_storage, text="Google Sheets", variable=self.var_sheets).pack(anchor='w')
        ttk.Label(lf_storage, text="ID Spreadsheet:").pack(anchor='w')
        ttk.Entry(lf_storage, textvariable=self.var_sheets_id).pack(fill='x', pady=2)

        ttk.Button(frame, text="💾 Guardar Configuración", command=self.save_config).pack(pady=20)

    def setup_logs(self):
        self.txt_logs = scrolledtext.ScrolledText(self.tab_logs, state='disabled', height=20)
        self.txt_logs.pack(expand=True, fill='both', padx=10, pady=10)

    def log(self, msg):
        self.messages_queue.append(msg)

    def update_ui_loop(self):
        # Procesar logs pendientes
        while self.messages_queue:
            msg = self.messages_queue.pop(0)
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.txt_logs.configure(state='normal')
            self.txt_logs.insert('end', f"[{timestamp}] {msg}\n")
            self.txt_logs.see('end')
            self.txt_logs.configure(state='disabled')
        
        self.root.after(100, self.update_ui_loop)

    def save_config(self):
        try:
            if 'fuentes' not in self.config: self.config['fuentes'] = {}
            if 'storage' not in self.config: self.config['storage'] = {}

            self.config['fuentes']['whatsapp_enabled'] = self.var_whatsapp.get()
            self.config['fuentes']['carpeta_enabled'] = self.var_folder.get()
            self.config['fuentes']['carpeta_ruta'] = self.var_folder_path.get()
            
            self.config['storage']['excel_enabled'] = self.var_excel.get()
            self.config['storage']['excel_path'] = self.var_excel_path.get()
            self.config['storage']['sheets_enabled'] = self.var_sheets.get()
            self.config['storage']['sheets_id'] = self.var_sheets_id.get()
            
            with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            self.log("✅ Configuración guardada.")
        except Exception as e:
            self.log(f"❌ Error guardando: {e}")

    def start_system(self):
        if self.is_running: return
        self.save_config()
        self.is_running = True
        
        self.btn_start.config(state='disabled')
        self.btn_stop.config(state='normal')
        self.lbl_status.config(text="Estado: EJECUTANDO", foreground="green")
        
        # Thread para no congelar la UI
        threading.Thread(target=self._run_processes, daemon=True).start()

    def _run_processes(self):
        self.log("🚀 Iniciando sistema...")
        
        # API Python
        cmd = [sys.executable, "run.py"]
        self.process_api = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
        threading.Thread(target=self._read_output, args=(self.process_api, "API"), daemon=True).start()
        
        # Bot WhatsApp
        if self.var_whatsapp.get():
            self.log("📱 Iniciando WhatsApp...")
            try:
                subprocess.run(["node", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
                bot_cmd = ["node", "bot/index.js"]
                self.process_bot = subprocess.Popen(bot_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd="bot", bufsize=1)
                threading.Thread(target=self._read_output, args=(self.process_bot, "BOT"), daemon=True).start()
            except:
                self.log("❌ Node.js no encontrado. WhatsApp no iniciará.")

    def _read_output(self, proc, prefix):
        for line in iter(proc.stdout.readline, ''):
            if not self.is_running: break
            if line.strip():
                if "INFO" in line or "Error" in line or "✅" in line or "node" in prefix.lower():
                    self.log(f"{prefix}: {line.strip()}")

    def stop_system(self):
        self.is_running = False
        self.btn_start.config(state='normal')
        self.btn_stop.config(state='disabled')
        self.lbl_status.config(text="Estado: DETENIDO", foreground="red")
        
        if self.process_api: 
            try: self.process_api.terminate() 
            except: pass
        if self.process_bot:
            try: self.process_bot.terminate()
            except: pass
        self.log("⏹ Sistema detenido.")

    def stats_monitor(self):
        while True:
            if self.is_running:
                try:
                     with open('data/usage_log.json', 'r') as f:
                        data = json.load(f)
                        resumen = data.get('resumen', {})
                        # Actualizar labels mediante after para thread-safety
                        self.root.after(0, lambda: self.lbl_processed.config(
                            text=f"Procesados: {resumen.get('total_procesados', 0)}"))
                        self.root.after(0, lambda: self.lbl_cost.config(
                            text=f"Costo Total: ${resumen.get('costo_mostrado_usd', 0):.4f} USD"))
                except: pass
            time.sleep(5)

    def open_excel(self):
        path = self.var_excel_path.get()
        if os.path.exists(path):
            if sys.platform == "darwin": subprocess.run(["open", path])
            else: os.startfile(path)
        else:
            self.log(f"❌ Archivo no encontrado: {path}")

    def on_closing(self):
        self.stop_system()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = SystemLauncher(root)
    root.mainloop()
