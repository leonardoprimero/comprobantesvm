#!/usr/bin/env python3
"""
Launcher en MODO TEXTO (CLI) para diagnóstico.
Permite iniciar el sistema sin interfaz gráfica para descartar errores visuales.
"""
import os
import sys
import json
import time
import subprocess
import threading
from datetime import datetime

# Importar LicenseManager si existe, o usar mock
try:
    from app.license import LicenseManager
except ImportError as e:
    print(f"❌ Error importando app.license: {e}")
    sys.exit(1)

CONFIG_PATH = "config.json"

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def load_config():
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def check_license_cli(config):
    print("🔍 Verificando licencia...")
    client_id = config.get("client_id", "")
    license_url = config.get("license_url", "")
    
    if not client_id:
        print("⚠ Sin Client ID configurado (Modo Developer)")
        return True
        
    try:
        lm = LicenseManager(client_id, license_url)
        active, msg = lm.check_license()
        if active:
            print(f"✅ Licencia ACTIVA: {msg}")
            return True
        else:
            print(f"⛔ LICENCIA BLOQUEADA: {msg}")
            return False
    except Exception as e:
        print(f"⚠ Error de conexión de licencia: {e}")
        return True # Fail open para test

def stream_logs(proc, prefix):
    for line in iter(proc.stdout.readline, ''):
        if line:
            print(f"[{prefix}] {line.strip()}")

def main():
    clear()
    print("="*60)
    print("   SISTEMA DE COMPROBANTES - MODO TEXTO (DIAGNÓSTICO)")
    print("="*60)
    
    # 1. Chequeo de archivos
    print("\n1. Verificando archivos...")
    files = ["run.py", "config.json", "bot/index.js"]
    for f in files:
        if os.path.exists(f):
            print(f"  ✅ {f} encontrado")
        else:
            print(f"  ❌ {f} NO ENCONTRADO")
    
    # 2. Cargar config
    config = load_config()
    if not config:
        print("❌ No se pudo cargar config.json")
        return

    # 3. Licencia
    print("\n2. Test de Licencia...")
    if not check_license_cli(config):
        print("\n⛔ El sistema no puede iniciar por bloqueo de licencia.")
        return

    # 4. Iniciar
    print("\n3. Iniciando Sistema...")
    print("   Presione Ctrl+C para detener.")
    print("-" * 60)
    
    processes = []
    
    try:
        # Run API
        api_cmd = [sys.executable, "-u", "run.py"] # -u para unbuffered
        api_proc = subprocess.Popen(api_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        processes.append(api_proc)
        threading.Thread(target=stream_logs, args=(api_proc, "CEREBRO"), daemon=True).start()
        
        # Run Bot (si aplica)
        if config.get('fuentes', {}).get('whatsapp_enabled'):
            if os.path.exists("bot/index.js"):
                print("   Iniciando Bot WhatsApp...")
                # Ejecutar node index.js DESDE la carpeta bot
                bot_cmd = ["node", "index.js"]
                bot_proc = subprocess.Popen(bot_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd="bot", bufsize=1)
                processes.append(bot_proc)
                threading.Thread(target=stream_logs, args=(bot_proc, "WHATSAPP"), daemon=True).start()
            else:
                print("   ⚠ bot/index.js no existe, saltando bot.")
        
        # Mantener vivo
        while True:
            time.sleep(1)
            if api_proc.poll() is not None:
                print(f"❌ El cerebro se detuvo inesperadamente (Código {api_proc.returncode})")
                break
                
    except KeyboardInterrupt:
        print("\n\n🛑 Deteniendo sistema...")
    finally:
        for p in processes:
            p.terminate()
            
if __name__ == "__main__":
    main()
