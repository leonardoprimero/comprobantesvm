"""
Almacenamiento de transferencias en Excel local usando openpyxl.
"""
import os
from datetime import datetime
from typing import Optional
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from app.paths import resolve_appdata_path


# Headers del Excel
HEADERS = [
    "Fecha Aviso", "Fecha Depósito", "Monto", 
    "Emisor Nombre", "Banco Emisor", 
    "CBU Emisor", "CUIL Emisor", 
    "Cuenta Destino", "WhatsApp", 
    "Referencia", "Confianza"
]

# Estilos
HEADER_FONT = Font(bold=True, color="FFFFFF")
HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
DUPLICATE_FILL = PatternFill(start_color="FFFF99", end_color="FFFF99", fill_type="solid")


def _crear_excel_con_headers(ruta: str) -> Workbook:
    """Crea un nuevo archivo Excel con los headers formateados."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Transferencias"
    
    # Agregar headers
    for col, header in enumerate(HEADERS, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center")
    
    # Ajustar anchos de columna
    column_widths = [18, 15, 15, 25, 20, 25, 15, 20, 18, 20, 12]
    for i, width in enumerate(column_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width
    
    wb.save(ruta)
    return wb


def _detectar_duplicado(ws, fecha_deposito: str, monto: float) -> bool:
    """Detecta si ya existe una transferencia con la misma fecha y monto."""
    for row in ws.iter_rows(min_row=2, max_col=3, values_only=True):
        if row[1] and row[2]:  # Fecha Depósito y Monto
            row_fecha = str(row[1]).strip()
            try:
                row_monto = float(str(row[2]).replace('$', '').replace(',', '').strip())
                if row_fecha == fecha_deposito and abs(row_monto - monto) < 1.0:
                    return True
            except (ValueError, TypeError):
                continue
    return False


def guardar_en_excel(
    datos: dict,
    ruta_excel: str,
    whatsapp_from: str = "",
    timestamp_recepcion: str = "",
    cuenta_destino: str = "Cuenta Desconocida"
) -> dict:
    """
    Guarda una transferencia en un archivo Excel local.
    
    Args:
        datos: Diccionario con los datos extraídos del comprobante
        ruta_excel: Ruta al archivo Excel
        whatsapp_from: Número de WhatsApp del remitente
        timestamp_recepcion: Timestamp de recepción del comprobante
        cuenta_destino: Nombre de la cuenta destino identificada
        
    Returns:
        Dict con resultado de la operación
    """
    try:
        # Resolver ruta (relativa a AppData)
        ruta_excel = resolve_appdata_path(ruta_excel, fallback_name="transferencias.xlsx")

        # Crear directorio si no existe
        directorio = os.path.dirname(ruta_excel)
        if directorio and not os.path.exists(directorio):
            os.makedirs(directorio)
        
        # Cargar o crear archivo
        if os.path.exists(ruta_excel):
            wb = load_workbook(ruta_excel)
            ws = wb.active
        else:
            wb = _crear_excel_con_headers(ruta_excel)
            ws = wb.active
        
        # Formatear fecha recepción
        try:
            fecha_recepcion = datetime.fromisoformat(timestamp_recepcion.replace("Z", "+00:00"))
            fecha_formateada = fecha_recepcion.strftime("%d/%m/%Y %H:%M")
        except:
            fecha_formateada = timestamp_recepcion or datetime.now().strftime("%d/%m/%Y %H:%M")
        
        # Preparar datos
        monto = datos.get("monto_numerico", 0)
        fecha_deposito = str(datos.get("fecha_operacion", "")).strip()
        
        # Lógica para nombre de emisor (Manejo de Depósitos)
        emisor_nombre = datos.get("emisor_nombre", "")
        if not emisor_nombre:
            concepto = datos.get("concepto", "").lower()
            if "deposito" in concepto or "efectivo" in concepto:
                emisor_nombre = "DEPÓSITO EN EFECTIVO"
        
        # Convertir confianza a etiqueta
        confianza_val = datos.get("confianza", 0)
        confianza_str = "OPTIMA" if confianza_val >= 0.90 else "REVEER"
        
        # Detectar duplicado
        es_duplicado = _detectar_duplicado(ws, fecha_deposito, monto)
        
        # Preparar número de WhatsApp
        numero_wa = whatsapp_from.replace("@c.us", "") if whatsapp_from else ""
        
        # Crear fila
        fila = [
            fecha_formateada,               # A: Fecha Aviso
            fecha_deposito,                 # B: Fecha Depósito
            monto,                          # C: Monto
            emisor_nombre,                  # D: Nombre Emisor
            datos.get("banco_emisor", ""),  # E: Banco
            datos.get("emisor_cbu", ""),    # F: CBU Emisor
            datos.get("emisor_cuil", ""),   # G: CUIL Emisor
            cuenta_destino,                 # H: Cuenta Destino
            numero_wa,                      # I: WhatsApp
            datos.get("referencia", ""),    # J: Referencia
            confianza_str                   # K: Confianza
        ]
        
        # Agregar fila
        ws.append(fila)
        nueva_fila = ws.max_row
        
        # Marcar como duplicado si corresponde
        if es_duplicado:
            for col in range(1, len(HEADERS) + 1):
                ws.cell(row=nueva_fila, column=col).fill = DUPLICATE_FILL
        
        # Guardar
        wb.save(ruta_excel)
        
        return {
            "success": True,
            "message": "Guardado en Excel" + (" (Duplicado)" if es_duplicado else ""),
            "ruta": ruta_excel,
            "fila": nueva_fila,
            "es_duplicado": es_duplicado
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
