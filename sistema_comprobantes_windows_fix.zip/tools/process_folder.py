import base64
import json
import mimetypes
import os
from datetime import datetime

from app.extractor import extraer_datos_comprobante
from storage.storage_manager import guardar_transferencia

SUPPORTED_EXT = {".jpg", ".jpeg", ".png", ".pdf"}

def guess_mime(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        return "application/pdf"
    if ext in {".jpg", ".jpeg"}:
        return "image/jpeg"
    if ext == ".png":
        return "image/png"
    mt, _ = mimetypes.guess_type(path)
    return mt or "application/octet-stream"


def load_config() -> dict:
    # Prefer repo-local config.json
    here = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    cfg_path = os.path.join(here, "config.json")
    if os.path.exists(cfg_path):
        with open(cfg_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def main():
    folder = os.environ.get("COMPROBANTES_DIR", os.path.expanduser("~/Downloads/comprobantes"))
    config = load_config()

    files = []
    for name in os.listdir(folder):
        p = os.path.join(folder, name)
        if not os.path.isfile(p):
            continue
        ext = os.path.splitext(name)[1].lower()
        if ext in SUPPORTED_EXT:
            files.append(p)

    files.sort(key=lambda p: os.path.getmtime(p))

    print(f"Carpeta: {folder}")
    print(f"Archivos a procesar: {len(files)}")

    ok = 0
    fail = 0
    for i, p in enumerate(files, 1):
        name = os.path.basename(p)
        mime = guess_mime(p)
        ts = datetime.fromtimestamp(os.path.getmtime(p)).isoformat()

        with open(p, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")

        print(f"\n[{i}/{len(files)}] {name} ({mime})")
        res = extraer_datos_comprobante(imagen_base64=b64, mime_type=mime)
        if not res.get("success"):
            print("  EXTRACTION_FAIL:", res.get("error"))
            fail += 1
            continue

        datos = res.get("data") or {}
        g = guardar_transferencia(
            datos=datos,
            config=config,
            whatsapp_from="",
            timestamp_recepcion=ts,
        )

        if g.get("success"):
            ok += 1
            print("  SAVED:", g.get("message"), "|", g.get("cuenta_destino"))
        else:
            fail += 1
            print("  SAVE_FAIL:", g.get("message"))

    print("\n=== RESUMEN ===")
    print("OK:", ok)
    print("FAIL:", fail)
    print("Excel:", (config.get("storage", {}) or {}).get("excel_path"))


if __name__ == "__main__":
    main()
